export class Employee {
    fName: string;
    lName: string;
    mNumber: number;
    emailID: string;
    jobTitle: string;
    dob: string;
    constructor(empval: any) {
        this.fName = empval.fName;
        this.lName = empval.lName;
        this.mNumber = empval.mNumber;
        this.emailID = empval.emailID;
        this.jobTitle = empval.jobTitle;
        this.dob = empval.dob;
    }
}