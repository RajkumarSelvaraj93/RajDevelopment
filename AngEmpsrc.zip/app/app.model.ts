export class Student {
    fName: string;
    lName: string;
    mNumber: number;
    constructor(stuentlist: any) {
            this.fName = stuentlist.fName || '';
            this.lName = stuentlist.lName || '';
            this.mNumber = stuentlist.mNumber || '';
    }
}