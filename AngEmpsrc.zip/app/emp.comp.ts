import { Component } from '@angular/core';
import { Employee } from './emp.model';
import { EmpService } from './emp.service';
@Component({
    selector: 'app-root',
    templateUrl: './emp.comp.html',
    styleUrls: ['./emp.comp.css'],
    providers: [EmpService]
})
export class EmpComponent {
    public EmployeeDetail = new Employee({});
    public EmployeeHidden: any = { "EmployeeDet": true, "EmployeeGrid": false };
    public EmployeeList: any = [];
    public EmpMode: string = "Add";
    public empIndex: number;
    public docattr: any;
    public docslidediv: any;
    constructor(private empservice: EmpService) {
        this.empservice.getEmpDet().subscribe(res => { this.EmployeeList = res; }, err => { alert(err); });
    }
    ngAfterViewInit() {
        this.docslidediv = document.getElementById('slidediv');
        this.docslidediv.setAttribute("data-cnt", "false");
    }
    AddGrid() {
        if (this.EmployeeDetail.fName && this.EmployeeDetail.lName && this.EmployeeDetail.mNumber && this.EmployeeDetail.emailID && this.EmployeeDetail.jobTitle && this.EmployeeDetail.dob) {
            let avoiddup: boolean = this.EmployeeList.some((emp, index) => {
                if (this.EmpMode == "Add")
                    return emp.mNumber == this.EmployeeDetail.mNumber && emp.emailID == this.EmployeeDetail.emailID;
                else if (index != this.empIndex)
                    return emp.mNumber == this.EmployeeDetail.mNumber && emp.emailID == this.EmployeeDetail.emailID;
            });
            if (avoiddup) {
                alert("Data Already Exists!!");
                return false;
            }
            if (this.EmpMode == "Add") {
                this.EmployeeList.push(this.EmployeeDetail);
            }
            else {
                this.EmployeeList[this.empIndex] = this.EmployeeDetail;
            }

            this.EmpMode = "Add";
            this.ShowEmpTab();
            this.EmployeeDetail = new Employee({});
            //this.empservice.pushEmpDet(this.EmployeeList).subscribe(res => console.log(res), err => console.log(err));
        }
        else
            alert("Fill all the Fields!");
    }
    ShowEmpTab() {
        this.EmployeeHidden.EmployeeDet = !this.EmployeeHidden.EmployeeDet;
        this.EmployeeHidden.EmployeeGrid = !this.EmployeeHidden.EmployeeGrid;

        if (this.docslidediv.getAttribute("data-cnt") == "true")
            this.docslidediv.setAttribute("data-cnt", "false");
        else
            this.docslidediv.setAttribute("data-cnt", "true");
    }
    GridEvent(eve, empval) {
        if (eve == "edit") {
            this.empIndex = this.EmployeeList.indexOf(empval);
            this.EmpMode = "Edit"
            this.EmployeeDetail = new Employee(empval);
            this.ShowEmpTab();
        }
        else {
            if (this.EmployeeList.indexOf(empval) != -1) {
                this.EmployeeList.splice(this.EmployeeList.indexOf(empval), 1);
            }
        }
    }
}