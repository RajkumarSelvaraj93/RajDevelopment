import { Http } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable()
export class EmpService {
    constructor(private http: Http) {

    }
    getEmpDet(): Observable<any> {
        return this.http.get("assets/emp.json.txt", "{ responseType: 'text' }").pipe(map(result => { return result.json(); }));
    }
    pushEmpDet(data): Observable<any> {
      return;
    }
}








