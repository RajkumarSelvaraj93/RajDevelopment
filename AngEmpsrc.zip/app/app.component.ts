import { Component } from '@angular/core';
import { Student } from './app.model';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';
  private StudentForm: any = new Student({});
  private StudentList: any = [];
  constructor() {
  }
  AddGrid(val) {
    if (val == "set") {
      if (this.StudentForm && this.StudentForm.fName && this.StudentForm.lName && this.StudentForm.mNumber) {
        this.StudentList.push(this.StudentForm);
        this.StudentList = Array.from(new Set(this.StudentList.map(JSON.stringify)));
        this.StudentList = this.StudentList.map(JSON.parse);
        this.StudentForm = new Student({});
      }
      else
        alert('Something went wrong. Maybe Field Empty or Already Exists');
    }
    else {
      if (this.StudentForm && this.StudentForm.fName && this.StudentForm.lName && this.StudentForm.mNumber && this.StudentList.indexOf(this.StudentForm) == -1) {
        this.StudentList.push(this.StudentForm);
        this.StudentForm = new Student({});
      }
      else
        alert('Something went wrong. Maybe Field Empty or Already Exists');
    }

  }

}
